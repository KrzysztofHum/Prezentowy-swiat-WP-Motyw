<?php get_header(); ?>
<main class="container mx-auto p-5">
    <h1 class="text-3xl font-bold text-primary">Hello from Prezentowy Świat Starter!</h1>
</main>
<?php get_footer(); ?>
